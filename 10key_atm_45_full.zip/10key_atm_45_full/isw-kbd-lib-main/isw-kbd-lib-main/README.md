# isw-kbd-lib

> [!WARNING]
> * Specifications of this footprint are subject to change without notice!
> * The Choc socket footprint does not support the Choc V2 Fix pins.